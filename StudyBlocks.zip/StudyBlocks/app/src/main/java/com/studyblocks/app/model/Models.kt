package com.studyblocks.app.model

enum class BlockStatus { NOT_STARTED, IN_PROGRESS, PAUSED, COMPLETE }

enum class ThemeMode { SYSTEM, LIGHT, DARK }

data class StudyBlock(
    val number: Int,
    var subject: String,
    var target: String = "",
    var status: BlockStatus = BlockStatus.NOT_STARTED,
    var startTime: Long = 0L,
    var endTime: Long = 0L,
    var remainingWhenPaused: Long = 0L,
    var actualMinutes: Int = 0,
    var reflection: String = "",
    var isOptional: Boolean = false
)

data class DaySession(
    var date: String,
    var coreBlockCount: Int,
    var blocks: MutableList<StudyBlock>,
    var breakActive: Boolean = false,
    var breakEndTime: Long = 0L,
    var breakForBlock: Int = 0
)

data class HistoryEntry(
    val date: String,
    val coreCompleted: Int,
    val coreTotal: Int,
    val totalMinutes: Int
)

data class AppSettings(
    var blockDurationMinutes: Int = 90,
    var breakDurationMinutes: Int = 20,
    var coreBlockCount: Int = 7,
    var themeMode: ThemeMode = ThemeMode.SYSTEM,
    var remindersEnabled: Boolean = true,
    var persistentTimerEnabled: Boolean = false,
    var dailyStartReminderEnabled: Boolean = false,
    var dailyStartHour: Int = -1,
    var dailyStartMinute: Int = -1
)
