package com.studyblocks.app.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.studyblocks.app.R
import com.studyblocks.app.ui.MainActivity
import com.studyblocks.app.util.NotificationHelper

class TimerForegroundService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            @Suppress("DEPRECATION")
            stopForeground(true)
            stopSelf()
            return START_NOT_STICKY
        }

        val endTime = intent?.getLongExtra(EXTRA_END_TIME, 0L) ?: 0L
        val label = intent?.getStringExtra(EXTRA_LABEL) ?: "Study Blocks"
        if (endTime <= 0L) {
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(NotificationHelper.NOTIF_ID_TIMER, buildNotification(endTime, label))
        return START_NOT_STICKY
    }

    private fun buildNotification(endTime: Long, label: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pi = PendingIntent.getActivity(
            this, 7000, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, NotificationHelper.CHANNEL_TIMER)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(label)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setUsesChronometer(true)
            .setChronometerCountDown(true)
            .setShowWhen(true)
            .setWhen(endTime)
            .setContentIntent(pi)
            .build()
    }

    companion object {
        private const val ACTION_STOP = "com.studyblocks.app.action.STOP_TIMER_SERVICE"
        private const val EXTRA_END_TIME = "endTime"
        private const val EXTRA_LABEL = "label"

        fun start(context: Context, endTimeMillis: Long, label: String) {
            val intent = Intent(context, TimerForegroundService::class.java).apply {
                putExtra(EXTRA_END_TIME, endTimeMillis)
                putExtra(EXTRA_LABEL, label)
            }
            ContextCompat.startForegroundService(context, intent)
        }

        /** Safe to call even if the service isn't running. */
        fun stop(context: Context) {
            val intent = Intent(context, TimerForegroundService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }
}
