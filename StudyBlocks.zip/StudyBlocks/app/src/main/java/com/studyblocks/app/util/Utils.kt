package com.studyblocks.app.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object DateUtils {
    private val storageFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val displayFormat = SimpleDateFormat("MMMM d", Locale.getDefault())

    fun todayKey(): String = storageFormat.format(Date())

    fun displayDate(key: String): String {
        return try {
            val d = storageFormat.parse(key)
            if (d != null) displayFormat.format(d) else key
        } catch (e: Exception) {
            key
        }
    }

    /** Whole calendar days between two yyyy-MM-dd keys (laterKey - earlierKey). */
    fun daysBetween(earlierKey: String, laterKey: String): Int {
        return try {
            val a = storageFormat.parse(earlierKey)!!.time
            val b = storageFormat.parse(laterKey)!!.time
            ((b - a) / (24L * 60L * 60L * 1000L)).toInt()
        } catch (e: Exception) {
            Int.MAX_VALUE
        }
    }
}

object TimeUtils {
    fun formatCountdown(millis: Long): String {
        val safe = if (millis < 0) 0 else millis
        val totalSeconds = safe / 1000
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        return String.format(Locale.US, "%02d:%02d", minutes, seconds)
    }

    fun minutesFromMillis(millis: Long): Int {
        if (millis <= 0) return 0
        return ((millis + 30_000L) / 60_000L).toInt()
    }

    /**
     * Minutes of actual focused time consumed so far, whether the block finished
     * naturally, was ended early, or is being queried mid-pause. Works the same way
     * regardless of how many times the block was paused and resumed, because
     * remainingWhenPaused / endTime always reflect only the time left in the
     * original planned budget - never wall-clock time spent paused.
     */
    fun computeActualMinutes(
        plannedMinutes: Int,
        isPaused: Boolean,
        remainingWhenPaused: Long,
        endTime: Long,
        now: Long
    ): Int {
        val plannedMillis = plannedMinutes * 60_000L
        val remaining = if (isPaused) remainingWhenPaused else (endTime - now).coerceAtLeast(0L)
        val consumed = (plannedMillis - remaining).coerceAtLeast(0L)
        return minutesFromMillis(consumed)
    }
}
