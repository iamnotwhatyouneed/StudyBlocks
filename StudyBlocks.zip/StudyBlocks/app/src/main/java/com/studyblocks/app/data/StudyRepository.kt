package com.studyblocks.app.data

import android.content.Context
import android.content.SharedPreferences
import com.studyblocks.app.model.AppSettings
import com.studyblocks.app.model.BlockStatus
import com.studyblocks.app.model.DaySession
import com.studyblocks.app.model.HistoryEntry
import com.studyblocks.app.model.StudyBlock
import com.studyblocks.app.model.ThemeMode
import com.studyblocks.app.util.DateUtils
import org.json.JSONArray
import org.json.JSONObject

/**
 * Single source of truth for all local data. Everything is stored as JSON strings
 * inside one SharedPreferences file - no database, no external dependency.
 */
class StudyRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("study_blocks_prefs", Context.MODE_PRIVATE)

    // ---------- Settings ----------

    fun loadSettings(): AppSettings {
        val s = prefs.getString(KEY_SETTINGS, null) ?: return AppSettings()
        return try {
            val o = JSONObject(s)
            AppSettings(
                blockDurationMinutes = o.optInt("blockDurationMinutes", 90),
                breakDurationMinutes = o.optInt("breakDurationMinutes", 20),
                coreBlockCount = o.optInt("coreBlockCount", 7),
                themeMode = parseThemeMode(o.optString("themeMode", "SYSTEM")),
                remindersEnabled = o.optBoolean("remindersEnabled", true),
                persistentTimerEnabled = o.optBoolean("persistentTimerEnabled", false),
                dailyStartReminderEnabled = o.optBoolean("dailyStartReminderEnabled", false),
                dailyStartHour = o.optInt("dailyStartHour", -1),
                dailyStartMinute = o.optInt("dailyStartMinute", -1)
            )
        } catch (e: Exception) {
            AppSettings()
        }
    }

    fun saveSettings(s: AppSettings) {
        prefs.edit().putString(KEY_SETTINGS, settingsToJson(s).toString()).apply()
    }

    private fun settingsToJson(s: AppSettings): JSONObject {
        val o = JSONObject()
        o.put("blockDurationMinutes", s.blockDurationMinutes)
        o.put("breakDurationMinutes", s.breakDurationMinutes)
        o.put("coreBlockCount", s.coreBlockCount)
        o.put("themeMode", s.themeMode.name)
        o.put("remindersEnabled", s.remindersEnabled)
        o.put("persistentTimerEnabled", s.persistentTimerEnabled)
        o.put("dailyStartReminderEnabled", s.dailyStartReminderEnabled)
        o.put("dailyStartHour", s.dailyStartHour)
        o.put("dailyStartMinute", s.dailyStartMinute)
        return o
    }

    private fun parseThemeMode(name: String): ThemeMode {
        return try { ThemeMode.valueOf(name) } catch (e: Exception) { ThemeMode.SYSTEM }
    }

    // ---------- Subject labels (persist across days, keyed by block position) ----------

    fun getSubjectLabel(index: Int, coreCount: Int): String {
        val map = loadSubjectLabels()
        return map[index.toString()] ?: defaultSubject(index, coreCount)
    }

    fun setSubjectLabel(index: Int, label: String) {
        val map = loadSubjectLabels()
        map[index.toString()] = label
        val o = JSONObject()
        for ((k, v) in map) o.put(k, v)
        prefs.edit().putString(KEY_SUBJECT_LABELS, o.toString()).apply()
    }

    private fun loadSubjectLabels(): MutableMap<String, String> {
        val map = mutableMapOf<String, String>()
        val s = prefs.getString(KEY_SUBJECT_LABELS, null) ?: return map
        try {
            val o = JSONObject(s)
            val it = o.keys()
            while (it.hasNext()) {
                val k = it.next()
                map[k] = o.getString(k)
            }
        } catch (e: Exception) {
            // ignore, return what we have
        }
        return map
    }

    private fun defaultSubject(index: Int, coreCount: Int): String {
        if (index == coreCount + 1) return "Backlog / Weak Areas"
        val roles = listOf(
            "Hardest Subject", "Hardest Subject", "Practice / Problem Solving",
            "Second Subject", "Active Recall / Practice",
            "Second Subject / Unfinished Work", "Revision + Testing"
        )
        return if (index <= roles.size) roles[index - 1] else "Block $index"
    }

    // ---------- Today / DaySession ----------

    fun loadRawToday(): DaySession? {
        val s = prefs.getString(KEY_TODAY, null) ?: return null
        return try {
            daySessionFromJson(JSONObject(s))
        } catch (e: Exception) {
            null
        }
    }

    fun saveToday(session: DaySession) {
        prefs.edit().putString(KEY_TODAY, daySessionToJson(session).toString()).apply()
    }

    /**
     * Ensures "today" reflects the current calendar date. If the stored session is from
     * an earlier date, archives it into history/streak and builds a fresh session using
     * the current settings and persisted subject labels. Call this at the top of every
     * screen that reads today's data, not just once at app start.
     */
    fun getOrCreateToday(): DaySession {
        val settings = loadSettings()
        val today = DateUtils.todayKey()
        val existing = loadRawToday()
        if (existing != null && existing.date == today) return existing

        if (existing != null) {
            archiveDay(existing)
        }

        val fresh = buildFreshSession(today, settings.coreBlockCount)
        saveToday(fresh)
        return fresh
    }

    private fun buildFreshSession(date: String, coreCount: Int): DaySession {
        val blocks = mutableListOf<StudyBlock>()
        for (i in 1..coreCount) {
            blocks.add(StudyBlock(number = i, subject = getSubjectLabel(i, coreCount)))
        }
        val optionalIndex = coreCount + 1
        blocks.add(
            StudyBlock(number = optionalIndex, subject = getSubjectLabel(optionalIndex, coreCount), isOptional = true)
        )
        return DaySession(date = date, coreBlockCount = coreCount, blocks = blocks)
    }

    private fun archiveDay(session: DaySession) {
        val coreCompleted = session.blocks.count { !it.isOptional && it.status == BlockStatus.COMPLETE }
        val totalMinutes = session.blocks.sumOf { it.actualMinutes }
        val fullyCompleted = coreCompleted >= session.coreBlockCount

        appendHistory(HistoryEntry(session.date, coreCompleted, session.coreBlockCount, totalMinutes))
        updateStreakOnRollover(session.date, fullyCompleted)
    }

    /**
     * Applies a new core-block-count immediately to today's list where safe (growing
     * always works; shrinking only applies today if it wouldn't discard a block that
     * already has progress - otherwise it takes effect starting tomorrow instead).
     */
    fun applyCoreBlockCountChange(newCount: Int) {
        val session = getOrCreateToday()
        if (newCount == session.coreBlockCount) return

        val currentCore = session.blocks.filter { !it.isOptional }
        val highestTouched = currentCore.filter { it.status != BlockStatus.NOT_STARTED }
            .maxOfOrNull { it.number } ?: 0
        if (newCount < highestTouched) return

        val newCoreBlocks = mutableListOf<StudyBlock>()
        for (i in 1..newCount) {
            val existing = currentCore.find { it.number == i }
            newCoreBlocks.add(existing ?: StudyBlock(number = i, subject = getSubjectLabel(i, newCount)))
        }
        val newOptionalIndex = newCount + 1
        val oldOptional = session.blocks.find { it.isOptional }
        val newOptional = if (oldOptional != null && oldOptional.number == newOptionalIndex) {
            oldOptional
        } else {
            StudyBlock(number = newOptionalIndex, subject = getSubjectLabel(newOptionalIndex, newCount), isOptional = true)
        }
        session.coreBlockCount = newCount
        session.blocks = (newCoreBlocks + newOptional).toMutableList()
        saveToday(session)
    }

    // ---------- History ----------

    fun loadHistory(): List<HistoryEntry> {
        val s = prefs.getString(KEY_HISTORY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(s)
            val list = mutableListOf<HistoryEntry>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    HistoryEntry(
                        o.getString("date"), o.getInt("coreCompleted"),
                        o.getInt("coreTotal"), o.getInt("totalMinutes")
                    )
                )
            }
            list.sortedByDescending { it.date }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun appendHistory(entry: HistoryEntry) {
        val current = loadHistory().toMutableList()
        current.removeAll { it.date == entry.date }
        current.add(entry)
        val arr = JSONArray()
        for (h in current.sortedByDescending { it.date }) {
            val o = JSONObject()
            o.put("date", h.date)
            o.put("coreCompleted", h.coreCompleted)
            o.put("coreTotal", h.coreTotal)
            o.put("totalMinutes", h.totalMinutes)
            arr.put(o)
        }
        prefs.edit().putString(KEY_HISTORY, arr.toString()).apply()
    }

    // ---------- Streak ----------
    // Streak counts consecutive fully-completed days, updated when a day rolls over.
    // The UI adds +1 on top of this for display when today itself is already fully done,
    // without persisting that +1 until tomorrow's rollover actually confirms it.

    fun loadStreak(): Int = prefs.getInt(KEY_STREAK_COUNT, 0)

    private fun updateStreakOnRollover(finishedDate: String, fullyCompleted: Boolean) {
        val lastCounted = prefs.getString(KEY_STREAK_LAST_DATE, null)
        if (lastCounted == finishedDate) return // already counted, avoid double increment

        if (!fullyCompleted) {
            prefs.edit().putInt(KEY_STREAK_COUNT, 0).remove(KEY_STREAK_LAST_DATE).apply()
            return
        }
        val current = loadStreak()
        val gapOk = lastCounted == null || DateUtils.daysBetween(lastCounted, finishedDate) == 1
        val updated = if (gapOk) current + 1 else 1
        prefs.edit().putInt(KEY_STREAK_COUNT, updated).putString(KEY_STREAK_LAST_DATE, finishedDate).apply()
    }

    // ---------- First launch ----------

    fun hasLaunchedBefore(): Boolean = prefs.getBoolean(KEY_LAUNCHED, false)
    fun setLaunchedBefore() { prefs.edit().putBoolean(KEY_LAUNCHED, true).apply() }

    // ---------- Backup / Restore (Section 21a) ----------

    fun exportAll(): String {
        val root = JSONObject()
        root.put("version", 1)
        root.put("settings", settingsToJson(loadSettings()))

        val labelsObj = JSONObject()
        for ((k, v) in loadSubjectLabels()) labelsObj.put(k, v)
        root.put("subjectLabels", labelsObj)

        loadRawToday()?.let { root.put("today", daySessionToJson(it)) }
        prefs.getString(KEY_HISTORY, null)?.let { root.put("history", JSONArray(it)) } ?: root.put("history", JSONArray())
        root.put("streakCount", loadStreak())
        prefs.getString(KEY_STREAK_LAST_DATE, null)?.let { root.put("streakLastDate", it) }
        return root.toString()
    }

    fun restoreAll(json: String): Boolean {
        return try {
            val root = JSONObject(json)
            if (root.optInt("version", -1) != 1) return false

            val editor = prefs.edit()
            editor.putString(KEY_SETTINGS, root.getJSONObject("settings").toString())
            if (root.has("subjectLabels")) {
                editor.putString(KEY_SUBJECT_LABELS, root.getJSONObject("subjectLabels").toString())
            }
            if (root.has("today")) {
                editor.putString(KEY_TODAY, root.getJSONObject("today").toString())
            }
            if (root.has("history")) {
                editor.putString(KEY_HISTORY, root.getJSONArray("history").toString())
            }
            editor.putInt(KEY_STREAK_COUNT, root.optInt("streakCount", 0))
            if (root.has("streakLastDate")) {
                editor.putString(KEY_STREAK_LAST_DATE, root.getString("streakLastDate"))
            }
            editor.putBoolean(KEY_LAUNCHED, true)
            editor.apply()
            true
        } catch (e: Exception) {
            false
        }
    }

    fun resetAllData() {
        prefs.edit().clear().apply()
    }

    // ---------- JSON <-> DaySession ----------

    private fun daySessionToJson(s: DaySession): JSONObject {
        val o = JSONObject()
        o.put("date", s.date)
        o.put("coreBlockCount", s.coreBlockCount)
        o.put("breakActive", s.breakActive)
        o.put("breakEndTime", s.breakEndTime)
        o.put("breakForBlock", s.breakForBlock)
        val arr = JSONArray()
        for (b in s.blocks) {
            val bo = JSONObject()
            bo.put("number", b.number)
            bo.put("subject", b.subject)
            bo.put("target", b.target)
            bo.put("status", b.status.name)
            bo.put("startTime", b.startTime)
            bo.put("endTime", b.endTime)
            bo.put("remainingWhenPaused", b.remainingWhenPaused)
            bo.put("actualMinutes", b.actualMinutes)
            bo.put("reflection", b.reflection)
            bo.put("isOptional", b.isOptional)
            arr.put(bo)
        }
        o.put("blocks", arr)
        return o
    }

    private fun daySessionFromJson(o: JSONObject): DaySession {
        val arr = o.getJSONArray("blocks")
        val blocks = mutableListOf<StudyBlock>()
        for (i in 0 until arr.length()) {
            val bo = arr.getJSONObject(i)
            val status = try {
                BlockStatus.valueOf(bo.optString("status", "NOT_STARTED"))
            } catch (e: Exception) {
                BlockStatus.NOT_STARTED
            }
            blocks.add(
                StudyBlock(
                    number = bo.getInt("number"),
                    subject = bo.optString("subject", "Block ${bo.getInt("number")}"),
                    target = bo.optString("target", ""),
                    status = status,
                    startTime = bo.optLong("startTime", 0L),
                    endTime = bo.optLong("endTime", 0L),
                    remainingWhenPaused = bo.optLong("remainingWhenPaused", 0L),
                    actualMinutes = bo.optInt("actualMinutes", 0),
                    reflection = bo.optString("reflection", ""),
                    isOptional = bo.optBoolean("isOptional", false)
                )
            )
        }
        return DaySession(
            date = o.getString("date"),
            coreBlockCount = o.getInt("coreBlockCount"),
            blocks = blocks,
            breakActive = o.optBoolean("breakActive", false),
            breakEndTime = o.optLong("breakEndTime", 0L),
            breakForBlock = o.optInt("breakForBlock", 0)
        )
    }

    companion object {
        private const val KEY_SETTINGS = "settings"
        private const val KEY_SUBJECT_LABELS = "subject_labels"
        private const val KEY_TODAY = "today"
        private const val KEY_HISTORY = "history"
        private const val KEY_STREAK_COUNT = "streak_count"
        private const val KEY_STREAK_LAST_DATE = "streak_last_date"
        private const val KEY_LAUNCHED = "has_launched"
    }
}
