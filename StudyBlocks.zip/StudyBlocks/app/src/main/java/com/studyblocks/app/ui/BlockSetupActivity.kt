package com.studyblocks.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.studyblocks.app.alarm.AlarmScheduler
import com.studyblocks.app.data.StudyRepository
import com.studyblocks.app.databinding.ActivityBlockSetupBinding
import com.studyblocks.app.model.BlockStatus
import com.studyblocks.app.service.TimerForegroundService

class BlockSetupActivity : AppCompatActivity() {

    private lateinit var binding: ActivityBlockSetupBinding
    private val repo by lazy { StudyRepository(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBlockSetupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val blockNumber = intent.getIntExtra("blockNumber", -1)
        val session = repo.getOrCreateToday()
        val block = session.blocks.find { it.number == blockNumber }
        if (block == null) {
            finish()
            return
        }

        binding.headerText.text = if (block.number == 1) "Let's start Block 1" else "Block ${block.number} \u2014 ready?"
        binding.blockTitleText.text = if (block.isOptional) {
            "Bonus block"
        } else {
            "Block ${block.number} of ${session.coreBlockCount}"
        }
        binding.subjectInput.setText(block.subject)
        binding.targetInput.setText(block.target)

        binding.startBlockButton.setOnClickListener {
            val settings = repo.loadSettings()

            val subject = binding.subjectInput.text.toString().trim().ifBlank { block.subject }
            repo.setSubjectLabel(block.number, subject)
            block.subject = subject
            block.target = binding.targetInput.text.toString().trim()

            val now = System.currentTimeMillis()
            block.startTime = now
            block.endTime = now + settings.blockDurationMinutes * 60_000L
            block.remainingWhenPaused = 0L
            block.status = BlockStatus.IN_PROGRESS
            repo.saveToday(session)

            AlarmScheduler.scheduleBlockComplete(this, block.number, block.endTime)
            if (settings.persistentTimerEnabled) {
                TimerForegroundService.start(this, block.endTime, block.subject)
            }

            startActivity(Intent(this, TimerActivity::class.java).putExtra("blockNumber", block.number))
            finish()
        }
    }
}
