package com.studyblocks.app.ui

import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.studyblocks.app.alarm.AlarmScheduler
import com.studyblocks.app.data.StudyRepository
import com.studyblocks.app.databinding.ActivitySettingsBinding
import com.studyblocks.app.model.AppSettings
import com.studyblocks.app.model.BlockStatus
import com.studyblocks.app.model.ThemeMode
import com.studyblocks.app.service.TimerForegroundService
import com.studyblocks.app.util.DateUtils
import java.nio.charset.StandardCharsets
import java.util.Locale

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private val repo by lazy { StudyRepository(this) }
    private var pendingHour = -1
    private var pendingMinute = -1

    private val exportLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
            if (uri == null) return@registerForActivityResult
            try {
                contentResolver.openOutputStream(uri)?.use {
                    it.write(repo.exportAll().toByteArray(StandardCharsets.UTF_8))
                }
                Toast.makeText(this, "Backup saved", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Couldn't save the backup", Toast.LENGTH_SHORT).show()
            }
        }

    private val restoreLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri == null) return@registerForActivityResult
            try {
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                val json = bytes?.toString(StandardCharsets.UTF_8)
                if (json != null && repo.restoreAll(json)) {
                    Toast.makeText(this, "Backup restored", Toast.LENGTH_SHORT).show()
                    loadIntoUi()
                } else {
                    showMessage("Couldn't restore", "This backup file couldn't be read. It may be corrupted or from a different app.")
                }
            } catch (e: Exception) {
                showMessage("Couldn't restore", "This backup file couldn't be read. It may be corrupted or from a different app.")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.dailyStartSwitch.setOnCheckedChangeListener { _, checked ->
            binding.dailyStartTimeButton.isEnabled = checked
        }
        binding.dailyStartTimeButton.setOnClickListener { pickDailyStartTime() }
        binding.exportButton.setOnClickListener {
            exportLauncher.launch("studyblocks_backup_${DateUtils.todayKey()}.json")
        }
        binding.restoreButton.setOnClickListener {
            restoreLauncher.launch(arrayOf("*/*"))
        }
        binding.resetButton.setOnClickListener { confirmReset() }
        binding.saveSettingsButton.setOnClickListener { saveAndApply() }

        loadIntoUi()
    }

    private fun loadIntoUi() {
        val s = repo.loadSettings()
        binding.blockDurationInput.setText(s.blockDurationMinutes.toString())
        binding.breakDurationInput.setText(s.breakDurationMinutes.toString())
        binding.coreBlockCountInput.setText(s.coreBlockCount.toString())

        when (s.themeMode) {
            ThemeMode.SYSTEM -> binding.themeGroup.check(binding.themeSystem.id)
            ThemeMode.LIGHT -> binding.themeGroup.check(binding.themeLight.id)
            ThemeMode.DARK -> binding.themeGroup.check(binding.themeDark.id)
        }

        binding.remindersSwitch.isChecked = s.remindersEnabled
        binding.persistentTimerSwitch.isChecked = s.persistentTimerEnabled
        binding.dailyStartSwitch.isChecked = s.dailyStartReminderEnabled
        binding.dailyStartTimeButton.isEnabled = s.dailyStartReminderEnabled

        pendingHour = s.dailyStartHour
        pendingMinute = s.dailyStartMinute
        binding.dailyStartTimeButton.text = formatTime(pendingHour, pendingMinute)
    }

    private fun formatTime(hour: Int, minute: Int): String {
        if (hour < 0 || minute < 0) return "Set time"
        return String.format(Locale.US, "%02d:%02d", hour, minute)
    }

    private fun pickDailyStartTime() {
        val h = if (pendingHour >= 0) pendingHour else 8
        val m = if (pendingMinute >= 0) pendingMinute else 0
        TimePickerDialog(this, { _, hour, minute ->
            pendingHour = hour
            pendingMinute = minute
            binding.dailyStartTimeButton.text = formatTime(hour, minute)
        }, h, m, true).show()
    }

    private fun saveAndApply() {
        val old = repo.loadSettings()

        val blockDuration = binding.blockDurationInput.text.toString().toIntOrNull()
            ?.coerceIn(30, 180) ?: old.blockDurationMinutes
        val breakDuration = binding.breakDurationInput.text.toString().toIntOrNull()
            ?.coerceIn(5, 60) ?: old.breakDurationMinutes
        val coreCount = binding.coreBlockCountInput.text.toString().toIntOrNull()
            ?.coerceIn(3, 10) ?: old.coreBlockCount

        val theme = when (binding.themeGroup.checkedRadioButtonId) {
            binding.themeLight.id -> ThemeMode.LIGHT
            binding.themeDark.id -> ThemeMode.DARK
            else -> ThemeMode.SYSTEM
        }
        val dailyEnabled = binding.dailyStartSwitch.isChecked && pendingHour >= 0

        val updated = AppSettings(
            blockDurationMinutes = blockDuration,
            breakDurationMinutes = breakDuration,
            coreBlockCount = coreCount,
            themeMode = theme,
            remindersEnabled = binding.remindersSwitch.isChecked,
            persistentTimerEnabled = binding.persistentTimerSwitch.isChecked,
            dailyStartReminderEnabled = dailyEnabled,
            dailyStartHour = pendingHour,
            dailyStartMinute = pendingMinute
        )
        repo.saveSettings(updated)

        if (coreCount != old.coreBlockCount) {
            repo.applyCoreBlockCountChange(coreCount)
        }

        AppCompatDelegate.setDefaultNightMode(
            when (theme) {
                ThemeMode.LIGHT -> AppCompatDelegate.MODE_NIGHT_NO
                ThemeMode.DARK -> AppCompatDelegate.MODE_NIGHT_YES
                ThemeMode.SYSTEM -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            }
        )

        if (dailyEnabled) {
            AlarmScheduler.scheduleDailyStart(this, pendingHour, pendingMinute)
        } else {
            AlarmScheduler.cancelDailyStart(this)
        }

        resyncPersistentTimer(updated)

        Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show()
        finish()
    }

    /** The persistent notification (if any) must always reflect the current toggle right away. */
    private fun resyncPersistentTimer(settings: AppSettings) {
        if (!settings.persistentTimerEnabled) {
            TimerForegroundService.stop(this)
            return
        }
        val session = repo.getOrCreateToday()
        val inProgress = session.blocks.find { it.status == BlockStatus.IN_PROGRESS }
        when {
            inProgress != null -> TimerForegroundService.start(this, inProgress.endTime, inProgress.subject)
            session.breakActive -> TimerForegroundService.start(this, session.breakEndTime, "Break")
            else -> TimerForegroundService.stop(this)
        }
    }

    private fun confirmReset() {
        AlertDialog.Builder(this)
            .setTitle("Reset all data?")
            .setMessage("This will erase every block, all history, and your streak. This cannot be undone.")
            .setPositiveButton("Erase everything") { _, _ -> performReset() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun performReset() {
        repo.resetAllData()
        AlarmScheduler.cancelDailyStart(this)
        TimerForegroundService.stop(this)
        val intent = Intent(this, WelcomeActivity::class.java)
            .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        startActivity(intent)
        finishAffinity()
    }

    private fun showMessage(title: String, message: String) {
        AlertDialog.Builder(this).setTitle(title).setMessage(message)
            .setPositiveButton("OK", null).show()
    }
}
