package com.studyblocks.app.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.studyblocks.app.data.StudyRepository
import com.studyblocks.app.model.BlockStatus
import com.studyblocks.app.service.TimerForegroundService
import com.studyblocks.app.util.NotificationHelper
import com.studyblocks.app.util.TimeUtils

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            AlarmScheduler.ACTION_BLOCK_COMPLETE -> handleBlockComplete(context, intent)
            AlarmScheduler.ACTION_BREAK_COMPLETE -> handleBreakComplete(context, intent)
            AlarmScheduler.ACTION_DAILY_START -> handleDailyStart(context)
        }
    }

    private fun handleBlockComplete(context: Context, intent: Intent) {
        val blockNumber = intent.getIntExtra(AlarmScheduler.EXTRA_BLOCK_NUMBER, -1)
        val targetTime = intent.getLongExtra(AlarmScheduler.EXTRA_TARGET_TIME, 0L)
        if (blockNumber < 0) return

        val repo = StudyRepository(context)
        val session = repo.getOrCreateToday()
        val block = session.blocks.find { it.number == blockNumber } ?: return

        // Stale/duplicate guard: only act if this block is still running the exact
        // instance of the timer this alarm was scheduled for.
        if (block.status != BlockStatus.IN_PROGRESS || block.endTime != targetTime) return

        val settings = repo.loadSettings()
        block.actualMinutes = TimeUtils.computeActualMinutes(
            settings.blockDurationMinutes, false, 0L, block.endTime, System.currentTimeMillis()
        )
        block.status = BlockStatus.COMPLETE
        repo.saveToday(session)

        TimerForegroundService.stop(context)
        if (settings.remindersEnabled) {
            NotificationHelper.postBlockComplete(context, blockNumber)
        }
    }

    private fun handleBreakComplete(context: Context, intent: Intent) {
        val nextBlockNumber = intent.getIntExtra(AlarmScheduler.EXTRA_BLOCK_NUMBER, -1)
        val targetTime = intent.getLongExtra(AlarmScheduler.EXTRA_TARGET_TIME, 0L)
        if (nextBlockNumber < 0) return

        val repo = StudyRepository(context)
        val session = repo.getOrCreateToday()

        if (!session.breakActive || session.breakEndTime != targetTime) return

        session.breakActive = false
        repo.saveToday(session)

        TimerForegroundService.stop(context)
        val settings = repo.loadSettings()
        if (settings.remindersEnabled) {
            NotificationHelper.postBreakOver(context, nextBlockNumber)
        }
    }

    private fun handleDailyStart(context: Context) {
        val repo = StudyRepository(context)
        val settings = repo.loadSettings()
        if (!settings.dailyStartReminderEnabled || settings.dailyStartHour < 0) return

        val session = repo.getOrCreateToday()
        val firstBlock = session.blocks.find { it.number == 1 }
        if (firstBlock == null || firstBlock.status == BlockStatus.NOT_STARTED) {
            NotificationHelper.postDailyStart(context)
        }
        // Exact alarms are one-shot by design (avoids Doze drift) - re-arm tomorrow's.
        AlarmScheduler.scheduleDailyStart(context, settings.dailyStartHour, settings.dailyStartMinute)
    }
}
