package com.studyblocks.app.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

/**
 * One exact alarm per block/break/daily-nudge event (Section 11a). Timing always
 * comes from a precomputed end timestamp, never from polling. On API 31+, if the
 * user hasn't granted the exact-alarm permission, calls fall back to an inexact
 * "and-allow-while-idle" alarm rather than silently doing nothing.
 */
object AlarmScheduler {

    const val ACTION_BLOCK_COMPLETE = "com.studyblocks.app.action.BLOCK_COMPLETE"
    const val ACTION_BREAK_COMPLETE = "com.studyblocks.app.action.BREAK_COMPLETE"
    const val ACTION_DAILY_START = "com.studyblocks.app.action.DAILY_START"

    const val EXTRA_BLOCK_NUMBER = "blockNumber"
    const val EXTRA_TARGET_TIME = "targetTime"

    private const val REQUEST_BASE_BLOCK = 1000
    private const val REQUEST_BASE_BREAK = 2000
    private const val REQUEST_DAILY_START = 3000

    fun scheduleBlockComplete(context: Context, blockNumber: Int, endTime: Long) {
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = ACTION_BLOCK_COMPLETE
            putExtra(EXTRA_BLOCK_NUMBER, blockNumber)
            putExtra(EXTRA_TARGET_TIME, endTime)
        }
        schedule(context, REQUEST_BASE_BLOCK + blockNumber, intent, endTime)
    }

    fun cancelBlockComplete(context: Context, blockNumber: Int) {
        cancel(context, REQUEST_BASE_BLOCK + blockNumber, ACTION_BLOCK_COMPLETE)
    }

    /** [nextBlockNumber] is the block the break is leading into (used for both the request code and the notification text). */
    fun scheduleBreakComplete(context: Context, nextBlockNumber: Int, breakEndTime: Long) {
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = ACTION_BREAK_COMPLETE
            putExtra(EXTRA_BLOCK_NUMBER, nextBlockNumber)
            putExtra(EXTRA_TARGET_TIME, breakEndTime)
        }
        schedule(context, REQUEST_BASE_BREAK + nextBlockNumber, intent, breakEndTime)
    }

    fun cancelBreakComplete(context: Context, nextBlockNumber: Int) {
        cancel(context, REQUEST_BASE_BREAK + nextBlockNumber, ACTION_BREAK_COMPLETE)
    }

    fun scheduleDailyStart(context: Context, hour: Int, minute: Int) {
        if (hour < 0 || minute < 0) return
        val target = nextOccurrence(hour, minute)
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = ACTION_DAILY_START
            putExtra(EXTRA_TARGET_TIME, target)
        }
        schedule(context, REQUEST_DAILY_START, intent, target)
    }

    fun cancelDailyStart(context: Context) {
        cancel(context, REQUEST_DAILY_START, ACTION_DAILY_START)
    }

    private fun nextOccurrence(hour: Int, minute: Int): Long {
        val now = Calendar.getInstance()
        val target = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (!target.after(now)) {
            target.add(Calendar.DAY_OF_YEAR, 1)
        }
        return target.timeInMillis
    }

    private fun schedule(context: Context, requestCode: Int, intent: Intent, triggerAt: Long) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val canExact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()
        try {
            if (canExact) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            }
        } catch (e: SecurityException) {
            // Exact-alarm permission revoked between the check and the call; fall back.
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        }
    }

    private fun cancel(context: Context, requestCode: Int, action: String) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, AlarmReceiver::class.java).apply { this.action = action }
        val pi = PendingIntent.getBroadcast(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.cancel(pi)
    }
}
