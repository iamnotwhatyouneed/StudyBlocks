package com.studyblocks.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.studyblocks.app.data.StudyRepository
import com.studyblocks.app.databinding.ActivityReflectionBinding

class ReflectionActivity : AppCompatActivity() {

    private lateinit var binding: ActivityReflectionBinding
    private val repo by lazy { StudyRepository(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReflectionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val blockNumber = intent.getIntExtra("blockNumber", -1)
        val session = repo.getOrCreateToday()
        val block = session.blocks.find { it.number == blockNumber }
        if (block == null) {
            finish()
            return
        }

        binding.reflectionInput.hint = "What did you get done in Block ${block.number}?"
        binding.reflectionInput.setText(block.reflection)

        binding.saveButton.setOnClickListener {
            block.reflection = binding.reflectionInput.text.toString().trim()
            repo.saveToday(session)
            startActivity(Intent(this, BreakActivity::class.java).putExtra("blockNumber", blockNumber))
            finish()
        }
    }
}
