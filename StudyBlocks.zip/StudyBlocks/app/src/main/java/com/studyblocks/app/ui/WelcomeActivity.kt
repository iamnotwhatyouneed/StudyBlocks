package com.studyblocks.app.ui

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.studyblocks.app.data.StudyRepository
import com.studyblocks.app.databinding.ActivityWelcomeBinding
import java.nio.charset.StandardCharsets

class WelcomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityWelcomeBinding
    private val repo by lazy { StudyRepository(this) }

    private val notifPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* no-op either way */ }

    private val restoreLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri == null) return@registerForActivityResult
            try {
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                val json = bytes?.toString(StandardCharsets.UTF_8)
                if (json != null && repo.restoreAll(json)) {
                    Toast.makeText(this, "Backup restored", Toast.LENGTH_SHORT).show()
                    goToMain()
                } else {
                    showRestoreError()
                }
            } catch (e: Exception) {
                showRestoreError()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (repo.hasLaunchedBefore()) {
            goToMain()
            return
        }

        binding = ActivityWelcomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.startButton.setOnClickListener {
            repo.setLaunchedBefore()
            maybeRequestNotificationPermission()
            goToMain()
        }
        binding.restoreButton.setOnClickListener {
            restoreLauncher.launch(arrayOf("*/*"))
        }
    }

    private fun maybeRequestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    private fun showRestoreError() {
        AlertDialog.Builder(this)
            .setTitle("Couldn't restore")
            .setMessage("This backup file couldn't be read. It may be corrupted or from a different app.")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun goToMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
