package com.studyblocks.app.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.studyblocks.app.databinding.ItemHistoryBinding
import com.studyblocks.app.model.HistoryEntry
import com.studyblocks.app.util.DateUtils

class HistoryAdapter(private val entries: List<HistoryEntry>) : RecyclerView.Adapter<HistoryAdapter.VH>() {

    inner class VH(val binding: ItemHistoryBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemHistoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun getItemCount(): Int = entries.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val entry = entries[position]
        holder.binding.historyDateText.text = DateUtils.displayDate(entry.date)
        holder.binding.historyDetailText.text =
            "${entry.coreCompleted}/${entry.coreTotal} blocks \u00B7 ${entry.totalMinutes} focused minutes"
    }
}
