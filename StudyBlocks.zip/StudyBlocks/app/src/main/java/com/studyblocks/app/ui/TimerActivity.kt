package com.studyblocks.app.ui

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.studyblocks.app.alarm.AlarmScheduler
import com.studyblocks.app.data.StudyRepository
import com.studyblocks.app.databinding.ActivityTimerBinding
import com.studyblocks.app.model.BlockStatus
import com.studyblocks.app.model.StudyBlock
import com.studyblocks.app.service.TimerForegroundService
import com.studyblocks.app.util.TimeUtils

class TimerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTimerBinding
    private val repo by lazy { StudyRepository(this) }
    private var blockNumber: Int = -1
    private var block: StudyBlock? = null

    private val handler = Handler(Looper.getMainLooper())
    private val tickRunnable = Runnable { tick() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTimerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        blockNumber = intent.getIntExtra("blockNumber", -1)
        if (blockNumber < 0) {
            finish()
            return
        }

        binding.pauseResumeButton.setOnClickListener { togglePause() }
        binding.endBlockButton.setOnClickListener { finishBlock(early = true) }
    }

    override fun onResume() {
        super.onResume()
        val session = repo.getOrCreateToday()
        val b = session.blocks.find { it.number == blockNumber }
        if (b == null) {
            finish()
            return
        }
        if (b.status == BlockStatus.COMPLETE) {
            // The background alarm already finished this one while we were away.
            openReflection()
            return
        }
        block = b
        binding.subjectText.text = b.subject
        if (b.target.isBlank()) {
            binding.targetText.visibility = View.GONE
        } else {
            binding.targetText.visibility = View.VISIBLE
            binding.targetText.text = "Target: ${b.target}"
        }
        updateStatusLabels()
        handler.removeCallbacks(tickRunnable)
        handler.post(tickRunnable)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tickRunnable)
    }

    private fun updateStatusLabels() {
        val paused = block?.status == BlockStatus.PAUSED
        binding.statusLabel.text = if (paused) "Paused" else "Focus time"
        binding.pauseResumeButton.text = if (paused) "RESUME" else "PAUSE"
    }

    /** Decides for itself whether to reschedule - paused and completed states both stop the loop. */
    private fun tick() {
        val b = block ?: return
        if (b.status == BlockStatus.PAUSED) {
            binding.timerText.text = TimeUtils.formatCountdown(b.remainingWhenPaused)
            return
        }
        val remaining = b.endTime - System.currentTimeMillis()
        if (remaining <= 0) {
            binding.timerText.text = TimeUtils.formatCountdown(0)
            finishBlock(early = false)
            return
        }
        binding.timerText.text = TimeUtils.formatCountdown(remaining)
        handler.postDelayed(tickRunnable, 1000L)
    }

    private fun togglePause() {
        val session = repo.getOrCreateToday()
        val b = session.blocks.find { it.number == blockNumber } ?: return
        val now = System.currentTimeMillis()
        val settings = repo.loadSettings()

        if (b.status == BlockStatus.IN_PROGRESS) {
            b.remainingWhenPaused = (b.endTime - now).coerceAtLeast(0L)
            b.status = BlockStatus.PAUSED
            repo.saveToday(session)
            AlarmScheduler.cancelBlockComplete(this, blockNumber)
            TimerForegroundService.stop(this)
        } else if (b.status == BlockStatus.PAUSED) {
            b.endTime = now + b.remainingWhenPaused
            b.status = BlockStatus.IN_PROGRESS
            repo.saveToday(session)
            AlarmScheduler.scheduleBlockComplete(this, blockNumber, b.endTime)
            if (settings.persistentTimerEnabled) {
                TimerForegroundService.start(this, b.endTime, b.subject)
            }
        }
        block = b
        updateStatusLabels()
        handler.removeCallbacks(tickRunnable)
        handler.post(tickRunnable)
    }

    /** Safe to call even if the background alarm already completed this block. */
    private fun finishBlock(early: Boolean) {
        handler.removeCallbacks(tickRunnable)
        val session = repo.getOrCreateToday()
        val b = session.blocks.find { it.number == blockNumber }
        if (b != null && b.status != BlockStatus.COMPLETE) {
            val settings = repo.loadSettings()
            val now = System.currentTimeMillis()
            b.actualMinutes = TimeUtils.computeActualMinutes(
                settings.blockDurationMinutes, b.status == BlockStatus.PAUSED, b.remainingWhenPaused, b.endTime, now
            )
            b.status = BlockStatus.COMPLETE
            if (early) b.endTime = now
            repo.saveToday(session)
        }
        AlarmScheduler.cancelBlockComplete(this, blockNumber)
        TimerForegroundService.stop(this)
        openReflection()
    }

    private fun openReflection() {
        startActivity(Intent(this, ReflectionActivity::class.java).putExtra("blockNumber", blockNumber))
        finish()
    }
}
