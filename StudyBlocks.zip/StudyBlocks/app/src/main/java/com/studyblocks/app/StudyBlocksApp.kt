package com.studyblocks.app

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import com.studyblocks.app.data.StudyRepository
import com.studyblocks.app.model.ThemeMode
import com.studyblocks.app.util.NotificationHelper

class StudyBlocksApp : Application() {

    override fun onCreate() {
        super.onCreate()
        NotificationHelper.ensureChannels(this)

        val mode = StudyRepository(this).loadSettings().themeMode
        AppCompatDelegate.setDefaultNightMode(
            when (mode) {
                ThemeMode.LIGHT -> AppCompatDelegate.MODE_NIGHT_NO
                ThemeMode.DARK -> AppCompatDelegate.MODE_NIGHT_YES
                ThemeMode.SYSTEM -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            }
        )
    }
}
