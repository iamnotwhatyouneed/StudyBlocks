package com.studyblocks.app.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.studyblocks.app.R
import com.studyblocks.app.ui.BlockSetupActivity
import com.studyblocks.app.ui.ReflectionActivity

object NotificationHelper {
    const val CHANNEL_REMINDERS = "reminders"
    const val CHANNEL_TIMER = "persistent_timer"
    const val NOTIF_ID_REMINDER_BASE = 501
    const val NOTIF_ID_TIMER = 502

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL_REMINDERS) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_REMINDERS, "Block & break alerts", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
        if (nm.getNotificationChannel(CHANNEL_TIMER) == null) {
            val ch = NotificationChannel(CHANNEL_TIMER, "Ongoing timer", NotificationManager.IMPORTANCE_LOW)
            ch.setSound(null, null)
            nm.createNotificationChannel(ch)
        }
    }

    fun postBlockComplete(context: Context, blockNumber: Int) {
        val intent = Intent(context, ReflectionActivity::class.java).apply {
            putExtra("blockNumber", blockNumber)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pi = PendingIntent.getActivity(
            context, 4000 + blockNumber, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notif = NotificationCompat.Builder(context, CHANNEL_REMINDERS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("\u2713 Block $blockNumber complete")
            .setContentText("Log your output")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        notify(context, NOTIF_ID_REMINDER_BASE + blockNumber, notif)
    }

    fun postBreakOver(context: Context, nextBlockNumber: Int) {
        val intent = Intent(context, BlockSetupActivity::class.java).apply {
            putExtra("blockNumber", nextBlockNumber)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pi = PendingIntent.getActivity(
            context, 5000 + nextBlockNumber, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notif = NotificationCompat.Builder(context, CHANNEL_REMINDERS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Break's over")
            .setContentText("Block $nextBlockNumber is ready")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        notify(context, NOTIF_ID_REMINDER_BASE + 900 + nextBlockNumber, notif)
    }

    fun postDailyStart(context: Context) {
        val intent = Intent(context, BlockSetupActivity::class.java).apply {
            putExtra("blockNumber", 1)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pi = PendingIntent.getActivity(
            context, 6000, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notif = NotificationCompat.Builder(context, CHANNEL_REMINDERS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Ready for Block 1?")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        notify(context, 6501, notif)
    }

    private fun notify(context: Context, id: Int, notif: android.app.Notification) {
        try {
            NotificationManagerCompat.from(context).notify(id, notif)
        } catch (e: SecurityException) {
            // POST_NOTIFICATIONS not granted; skip silently.
        }
    }
}
