package com.studyblocks.app.ui

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.studyblocks.app.alarm.AlarmScheduler
import com.studyblocks.app.data.StudyRepository
import com.studyblocks.app.databinding.ActivityBreakBinding
import com.studyblocks.app.service.TimerForegroundService
import com.studyblocks.app.util.TimeUtils

class BreakActivity : AppCompatActivity() {

    private lateinit var binding: ActivityBreakBinding
    private val repo by lazy { StudyRepository(this) }
    private var blockNumber: Int = -1
    private var hasNextBlock: Boolean = true

    private val handler = Handler(Looper.getMainLooper())
    private val tickRunnable = Runnable { tick() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBreakBinding.inflate(layoutInflater)
        setContentView(binding.root)

        blockNumber = intent.getIntExtra("blockNumber", -1)
        val session = repo.getOrCreateToday()
        val completedBlock = session.blocks.find { it.number == blockNumber }
        if (completedBlock == null) {
            finish()
            return
        }
        hasNextBlock = !completedBlock.isOptional

        binding.break15.setOnClickListener { startBreak(15) }
        binding.break20.setOnClickListener { startBreak(20) }
        binding.break30.setOnClickListener { startBreak(30) }
        binding.skipBreakButton.setOnClickListener { proceedAfterBreak() }
        binding.endBreakButton.setOnClickListener { proceedAfterBreak() }
    }

    override fun onResume() {
        super.onResume()
        refreshState()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tickRunnable)
    }

    private fun refreshState() {
        val session = repo.getOrCreateToday()
        if (session.breakActive) {
            if (System.currentTimeMillis() >= session.breakEndTime) {
                // Already elapsed - e.g. we were away when it ended. Resolve now
                // rather than show a stale countdown.
                proceedAfterBreak()
                return
            }
            showCounting()
            handler.removeCallbacks(tickRunnable)
            handler.post(tickRunnable)
        } else {
            showChoosing()
        }
    }

    private fun showChoosing() {
        binding.chooseGroup.visibility = View.VISIBLE
        binding.countingGroup.visibility = View.GONE
    }

    private fun showCounting() {
        binding.chooseGroup.visibility = View.GONE
        binding.countingGroup.visibility = View.VISIBLE
    }

    private fun startBreak(minutes: Int) {
        val session = repo.getOrCreateToday()
        val now = System.currentTimeMillis()
        session.breakActive = true
        session.breakEndTime = now + minutes * 60_000L
        session.breakForBlock = blockNumber
        repo.saveToday(session)

        if (hasNextBlock) {
            AlarmScheduler.scheduleBreakComplete(this, blockNumber + 1, session.breakEndTime)
        }
        if (repo.loadSettings().persistentTimerEnabled) {
            TimerForegroundService.start(this, session.breakEndTime, "Break")
        }

        showCounting()
        handler.removeCallbacks(tickRunnable)
        handler.post(tickRunnable)
    }

    private fun tick() {
        val session = repo.getOrCreateToday()
        if (!session.breakActive) return
        val remaining = session.breakEndTime - System.currentTimeMillis()
        if (remaining <= 0) {
            binding.breakTimerText.text = TimeUtils.formatCountdown(0)
            proceedAfterBreak()
            return
        }
        binding.breakTimerText.text = TimeUtils.formatCountdown(remaining)
        handler.postDelayed(tickRunnable, 1000L)
    }

    private fun proceedAfterBreak() {
        handler.removeCallbacks(tickRunnable)
        val session = repo.getOrCreateToday()
        session.breakActive = false
        repo.saveToday(session)

        AlarmScheduler.cancelBreakComplete(this, blockNumber + 1)
        TimerForegroundService.stop(this)

        if (hasNextBlock) {
            startActivity(Intent(this, BlockSetupActivity::class.java).putExtra("blockNumber", blockNumber + 1))
        } else {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            )
        }
        finish()
    }
}
