package com.studyblocks.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.studyblocks.app.data.StudyRepository
import com.studyblocks.app.databinding.ActivityMainBinding
import com.studyblocks.app.model.BlockStatus
import com.studyblocks.app.model.DaySession
import com.studyblocks.app.model.StudyBlock
import com.studyblocks.app.util.DateUtils

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val repo by lazy { StudyRepository(this) }
    private var session: DaySession? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.blockList.layoutManager = LinearLayoutManager(this)
        binding.historyNav.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        binding.settingsNav.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val s = repo.getOrCreateToday()
        session = s

        val coreTotal = s.coreBlockCount
        val coreCompleted = s.blocks.count { !it.isOptional && it.status == BlockStatus.COMPLETE }

        val filled = "\u2588".repeat(coreCompleted)
        val empty = "\u2591".repeat((coreTotal - coreCompleted).coerceAtLeast(0))
        binding.progressBarText.text = "$filled$empty  $coreCompleted / $coreTotal"

        if (s.breakActive) {
            binding.blockCountText.text = "On a break \u2014 tap to return"
            binding.blockCountText.setOnClickListener {
                startActivity(Intent(this, BreakActivity::class.java).putExtra("blockNumber", s.breakForBlock))
            }
        } else {
            binding.blockCountText.text = DateUtils.displayDate(s.date)
            binding.blockCountText.setOnClickListener(null)
        }

        val storedStreak = repo.loadStreak()
        val displayStreak = if (coreCompleted >= coreTotal) storedStreak + 1 else storedStreak
        if (displayStreak > 0) {
            binding.streakText.visibility = View.VISIBLE
            binding.streakText.text = "$displayStreak day streak"
        } else {
            binding.streakText.visibility = View.GONE
        }

        if (coreCompleted >= coreTotal) {
            val totalMinutes = s.blocks.sumOf { it.actualMinutes }
            binding.endOfDayPanel.visibility = View.VISIBLE
            binding.endOfDaySummary.text = "All $coreTotal core blocks done. $totalMinutes minutes focused today."
        } else {
            binding.endOfDayPanel.visibility = View.GONE
        }

        binding.blockList.adapter = BlockAdapter(s.blocks) { block -> onBlockClicked(block) }
    }

    private fun onBlockClicked(block: StudyBlock) {
        val s = session ?: return
        when (block.status) {
            BlockStatus.COMPLETE -> {
                startActivity(Intent(this, ReflectionActivity::class.java).putExtra("blockNumber", block.number))
            }
            BlockStatus.IN_PROGRESS, BlockStatus.PAUSED -> {
                startActivity(Intent(this, TimerActivity::class.java).putExtra("blockNumber", block.number))
            }
            BlockStatus.NOT_STARTED -> {
                val nextActionable = s.blocks.firstOrNull { it.status == BlockStatus.NOT_STARTED }?.number
                if (block.number == nextActionable) {
                    startActivity(Intent(this, BlockSetupActivity::class.java).putExtra("blockNumber", block.number))
                } else {
                    Toast.makeText(this, "Finish the current block first", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
