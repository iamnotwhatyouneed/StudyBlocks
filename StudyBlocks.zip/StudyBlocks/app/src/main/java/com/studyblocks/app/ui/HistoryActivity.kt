package com.studyblocks.app.ui

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.studyblocks.app.data.StudyRepository
import com.studyblocks.app.databinding.ActivityHistoryBinding

class HistoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHistoryBinding
    private val repo by lazy { StudyRepository(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.historyList.layoutManager = LinearLayoutManager(this)
    }

    override fun onResume() {
        super.onResume()
        val entries = repo.loadHistory()
        if (entries.isEmpty()) {
            binding.emptyText.visibility = View.VISIBLE
            binding.historyList.visibility = View.GONE
        } else {
            binding.emptyText.visibility = View.GONE
            binding.historyList.visibility = View.VISIBLE
            binding.historyList.adapter = HistoryAdapter(entries)
        }
    }
}
