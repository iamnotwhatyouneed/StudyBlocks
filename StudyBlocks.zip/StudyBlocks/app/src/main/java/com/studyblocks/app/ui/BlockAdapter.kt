package com.studyblocks.app.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.studyblocks.app.databinding.ItemBlockBinding
import com.studyblocks.app.model.BlockStatus
import com.studyblocks.app.model.StudyBlock

class BlockAdapter(
    private val blocks: List<StudyBlock>,
    private val onClick: (StudyBlock) -> Unit
) : RecyclerView.Adapter<BlockAdapter.VH>() {

    inner class VH(val binding: ItemBlockBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemBlockBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun getItemCount(): Int = blocks.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val block = blocks[position]
        val b = holder.binding

        b.blockNumberText.text = if (block.isOptional) "Bonus block" else "Block ${block.number}"
        b.blockSubjectText.text = block.subject

        if (block.target.isBlank()) {
            b.blockTargetText.visibility = android.view.View.GONE
        } else {
            b.blockTargetText.visibility = android.view.View.VISIBLE
            b.blockTargetText.text = "Target: ${block.target}"
        }

        b.blockStatusText.text = when (block.status) {
            BlockStatus.NOT_STARTED -> "Not started"
            BlockStatus.IN_PROGRESS -> "In progress"
            BlockStatus.PAUSED -> "Paused"
            BlockStatus.COMPLETE -> "\u2713 Complete \u00B7 ${block.actualMinutes} min"
        }

        holder.itemView.setOnClickListener { onClick(block) }
    }
}
