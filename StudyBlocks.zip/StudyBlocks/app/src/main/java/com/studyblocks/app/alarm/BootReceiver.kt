package com.studyblocks.app.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.studyblocks.app.data.StudyRepository
import com.studyblocks.app.model.BlockStatus

class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return

        val repo = StudyRepository(context)
        // Recalculating "today" here also correctly archives a day that finished
        // entirely while the phone was off (Section 30 date-rollover case).
        val session = repo.getOrCreateToday()
        val settings = repo.loadSettings()

        val inProgress = session.blocks.find { it.status == BlockStatus.IN_PROGRESS }
        if (inProgress != null) {
            // Scheduling with a past endTime is fine - AlarmManager fires it almost
            // immediately, which correctly completes a block that finished while
            // the phone was off rather than losing that alarm silently.
            AlarmScheduler.scheduleBlockComplete(context, inProgress.number, inProgress.endTime)
        }

        if (session.breakActive) {
            val nextBlockNumber = session.breakForBlock + 1
            AlarmScheduler.scheduleBreakComplete(context, nextBlockNumber, session.breakEndTime)
        }

        if (settings.dailyStartReminderEnabled) {
            AlarmScheduler.scheduleDailyStart(context, settings.dailyStartHour, settings.dailyStartMinute)
        }
    }
}
