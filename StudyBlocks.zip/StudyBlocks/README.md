# Study Blocks

A native Android (Kotlin) implementation of the "7×90 Study System" master
prompt: seven 90-minute focus blocks a day, each running Cue → Craving →
Action → Reward, fully offline, no accounts, no cloud.

## Important: this has not been compiled or run

This sandbox has no Android SDK, no emulator, and no network access, so I
could not build an APK or run the app. Every file below was hand-written
against the real Android/AndroidX APIs and cross-checked for consistency
(every ViewBinding reference matched against its layout's `android:id`s,
every manifest-registered class confirmed to exist, every XML file
validated as well-formed), but **first-build fixes in Android Studio are
still possible.** Open the project, let Gradle sync, and build — if
anything doesn't compile, it's almost certainly a small, mechanical fix
(an import, a type mismatch), not a structural problem.

## Opening and building

1. Unzip, then in Android Studio: **Open** → select the `StudyBlocks` folder.
2. Let Gradle sync (it will download AGP 8.5.2 / Gradle 8.7 / Kotlin 1.9.24
   automatically — no `gradlew` wrapper jar is bundled, since Android
   Studio manages that itself on first sync).
3. Build → Run on a device/emulator, or **Build > Generate Signed/Unsigned
   APK** to sideload onto the Redmi Note 4 (enable "Install unknown apps"
   for whichever app you transfer the APK with).
4. minSdk 24 / targetSdk 34, so it installs on the Android 7.x target
   device as well as current ones.

## What's implemented

Everything in the master prompt: Welcome (Start / Restore backup) →
Today (progress bar, streak, block list, end-of-day summary) → Block
setup (rename subject, set today's target, start-ritual checklist) →
Timer (pause/resume, end early) → Reflection → Break (15/20/30/skip) →
loop to the next block, plus History and Settings. Notifications are
timestamp-driven `AlarmManager` alarms (not polling), survive the app
being killed via `AlarmReceiver`, and are re-armed after reboot via
`BootReceiver`. Backup/restore uses the Storage Access Framework, so no
storage permission is requested. `allowBackup="false"` keeps Android's
automatic cloud backup out of the picture entirely.

## Decisions the master prompt left open

The spec was thorough but a few things weren't fully pinned down. Here's
what I chose and why — change any of these if you'd rather have it work
differently:

1. **Subject names persist per block position, independent of the daily
   reset.** Renaming "Block 3" is stored separately from that day's
   status/target/timestamps, so the name carries forward tomorrow while
   the target and completion state reset each night.
2. **Streak counts consecutive fully-completed days**, updated when a day
   rolls over (broken by any gap or incomplete day). The Today screen
   shows `stored streak + 1` once every core block is done *today*,
   without persisting that +1 until tomorrow's rollover actually confirms
   it — so the number never lies, but you still see it tick up the moment
   you earn it.
3. **Changing the core block count mid-day** grows today's list
   immediately; it only shrinks today if that wouldn't discard a block
   that already has progress — otherwise the new count takes effect
   starting tomorrow. Nothing you've already done today is ever silently
   dropped.
4. **Break-duration range**: the spec gave block duration (30–180) and
   core block count (3–10) explicit ranges but left the break-length field
   open (default 20). I clamped it to 5–60 minutes as a sensible bound in
   the same spirit as the other two.

Two smaller implementation notes:

- The persistent countdown notification (off by default) uses the
  platform's native chronometer (`setUsesChronometer` +
  `setChronometerCountDown`, API 24+) exactly as the spec asks — the
  system redraws the number itself, the app doesn't wake up to do it —
  and `AlarmReceiver` clears it the moment a block/break actually ends,
  even if the app was never reopened. This is the piece most worth
  testing first, since it's the hardest to verify without a device.
- The five "before you start" checkboxes on the block-setup screen are
  intentionally decorative (not persisted), matching the spec's own
  framing of the start ritual as a mental cue rather than tracked data.

## Icons

The launcher icon and the notification's small icon are simple
self-authored shapes generated in this sandbox (a teal circle with a
checkmark), not final art — swap the mipmap PNGs and
`res/drawable/ic_notification.xml` for real ones whenever you like.
